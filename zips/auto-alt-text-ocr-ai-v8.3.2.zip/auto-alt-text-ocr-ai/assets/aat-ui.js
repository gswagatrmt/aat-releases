/* Auto Alt Text - admin page look (8.3.2): builds the job index and the safety chips from each section's own title and text, gives
   wrapping button groups a gap, and marks the section in view. It moves the existing sections into a two-column shell; it never
   changes a control, a name, an id or a handler. Classic look: define( 'AAT_UI_CLASSIC', true ) in wp-config.php. */
(function () {
  function init() {
    var W = document.querySelector('.wrap.aat-admin');
    if (!W || W.classList.contains('aat-ui')) { return; }
    /* section title -> [index label, job, risk]; risk: writes = changes the site, read = scan / review, '' = information.
       A title not listed (a translation, a new section) still gets an index entry under "Other", with no marker. */
    var MAP = [
      [/^Process Information/, 'Progress', 'Alt text', ''], [/^Process Images/, 'Generate alt text', 'Alt text', 'writes'],
      [/^Important Notes/, 'How it works', 'Alt text', ''], [/^Scan Post/, 'Scan content', 'Alt text', 'read'],
      [/^Screaming Frog/, 'Screaming Frog inlinks', 'Alt text', 'writes'], [/^Maintenance/, 'Maintenance', 'Site fixes', 'writes'],
      [/^Internal Redirection/, 'Redirection fixer', 'Site fixes', 'writes'], [/^Internal Link Remover/, 'Link remover', 'Site fixes', 'writes'],
      [/^Bulk URL Drafter/, 'Draft / publish', 'Bulk SEO', 'writes'], [/^Bulk Meta/, 'Titles & descriptions', 'Bulk SEO', 'writes'],
      [/^Bulk Robots/, 'Robots', 'Bulk SEO', 'writes'], [/^Bulk Canonical/, 'Canonicals', 'Bulk SEO', 'writes'],
      [/^Undo History/, 'Undo history', 'Bulk SEO', ''], [/^Image Compression/, 'Image compression', 'Images', 'writes']
    ];
    var cards = [].slice.call(W.children).filter(function (c) {
      return c.classList && c.classList.contains('card') && c.querySelector(':scope > h2');
    });
    if (cards.length < 3) { return; }
    W.classList.add('aat-ui');
    var main = document.createElement('div'); main.className = 'aat-main';
    var nav = document.createElement('nav'); nav.className = 'aat-index'; nav.setAttribute('aria-label', 'Auto Alt Text tools');
    var shell = document.createElement('div'); shell.className = 'aat-shell'; shell.appendChild(nav); shell.appendChild(main);
    cards[0].parentNode.insertBefore(shell, cards[0]);
    var groups = {}, order = [];
    cards.forEach(function (c, i) {
      var h = c.querySelector(':scope > h2'), t = h.textContent.trim(), m = null;
      MAP.forEach(function (x) { if (!m && x[0].test(t)) { m = x; } });
      if (!m) { m = [null, t.length > 34 ? t.slice(0, 32) + '...' : t, 'Other', '']; }
      if (!c.id) { c.id = 'aat-s' + i; }
      c.setAttribute('data-risk', m[3]);
      main.appendChild(c);
      var txt = c.textContent, chips = [];
      if (m[3] === 'writes') { chips.push(['writes', /^Image Compression/.test(t) ? 'Changes image files' : (/^(Process Images|Screaming Frog)/.test(t) ? 'Saves alt text' : 'Writes to the database')]); }
      if (m[3] === 'read') { chips.push(['read', 'Scan first, apply what you pick']); }
      if (/Dry run/i.test(txt)) { chips.push(['dry', 'Dry run available']); }
      if (!/^Undo History/.test(t)) {
        if (/Restore originals/.test(txt)) { chips.push(['undo', 'Restore available']); }
        else if (/snapshotted for Undo|undo snapshot/i.test(txt)) { chips.push(['undo', 'Undo available']); }
      }
      if (/licensed feature|requires an active license/i.test(txt)) { chips.push(['lic', 'Licence needed']); }
      if (chips.length) {
        var cw = document.createElement('div'); cw.className = 'aat-chips';
        chips.forEach(function (x) { var s = document.createElement('span'); s.className = x[0]; s.textContent = x[1]; cw.appendChild(s); });
        h.insertAdjacentElement('afterend', cw);
      }
      if (!groups[m[2]]) { groups[m[2]] = []; order.push(m[2]); }
      groups[m[2]].push([c.id, m[1], m[3]]);
    });
    order.forEach(function (g) {
      var h3 = document.createElement('h3'); h3.textContent = g; nav.appendChild(h3);
      groups[g].forEach(function (x) {
        var a = document.createElement('a'); a.href = '#' + x[0];
        var mk = document.createElement('span'); mk.className = 'aat-m ' + x[2]; a.appendChild(mk);
        a.appendChild(document.createTextNode(x[1])); nav.appendChild(a);
      });
    });
    var key = document.createElement('p'); key.className = 'aat-key';
    key.innerHTML = '<span><span class="aat-m writes"></span>Changes the site</span><span><span class="aat-m read"></span>Scan, then review</span>';
    nav.appendChild(key);
    var h1 = W.querySelector('h1');
    if (h1) {
      var v = h1.textContent.match(/\(v([\d.]+)\)/);
      h1.textContent = 'Auto Alt Text';
      if (v) { var sv = document.createElement('span'); sv.className = 'aat-ver'; sv.textContent = 'v' + v[1]; h1.appendChild(sv); }
      var sub = document.createElement('p'); sub.className = 'aat-sub';
      sub.textContent = 'Alt text, content fixes and bulk SEO tools for this site. Tools marked amber change the site; each says how to undo it.';
      h1.insertAdjacentElement('afterend', sub);
    }
    /* button groups: a container of buttons only -> a wrapping row with a gap; a flex row without a gap -> a gap; mixed content ->
       margins on the buttons (turning it into a flex row would put its headings / paragraphs side by side) */
    [].forEach.call(main.querySelectorAll('div, p, td'), function (el) {
      var kids = [].filter.call(el.children, function (c) { return c.classList.contains('button'); });
      if (kids.length < 2) { return; }
      var d = getComputedStyle(el).display;
      if (d === 'flex' || d === 'inline-flex') { if (getComputedStyle(el).columnGap === 'normal' || getComputedStyle(el).columnGap === '0px') { el.classList.add('aat-flexgap'); } return; }
      if (d === 'none') { el.classList.add('aat-btngap'); return; }
      var other = [].some.call(el.children, function (c) { return !c.classList.contains('button') && !/^(SPAN|STRONG|EM|SMALL|A|INPUT|LABEL|SELECT)$/.test(c.tagName); });
      el.classList.add(other ? 'aat-btngap' : 'aat-btnrow');
    });
    var links = [].slice.call(nav.querySelectorAll('a'));
    var last = null;
    function mark() {
      var cur = links[0];
      links.forEach(function (a) { var el = document.getElementById(a.hash.slice(1)); if (el && el.getBoundingClientRect().top < 160) { cur = a; } });
      links.forEach(function (a) { a.setAttribute('aria-current', a === cur ? 'true' : 'false'); });
      if (cur && cur !== last && nav.scrollWidth > nav.clientWidth + 4) { nav.scrollLeft = cur.offsetLeft - 16; }
      last = cur;
    }
    window.addEventListener('scroll', mark, { passive: true });
    mark();
  }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init); } else { init(); }
})();
