<?php
/**
 * Self-hosted, signed plugin updates from a public GitHub "releases" repo (beta + stable channels).
 * Part of release-kit (see RELEASE-GUIDE.md). Copy this file into the plugin folder UNCHANGED and register it from the main file:
 *
 *   require_once __DIR__ . '/self-update.php';
 *   Swagat_Release_Updater_1::register( array(
 *       'file'    => __FILE__,                                                       // the main plugin file
 *       'name'    => 'My Plugin',                                                    // shown in update errors
 *       'base'    => 'https://raw.githubusercontent.com/<owner>/<slug>-releases/main/', // where beta.json / stable.json live
 *       'repo'    => 'https://github.com/<owner>/<slug>-releases',                   // = the plugin's "Update URI" header
 *       'pubkey'  => '<64 hex chars from keygen.php>',                               // the release key's PUBLIC half
 *       'context' => '<slug>-release:v1:',                                           // = "context" in release.json
 *       'prefix'  => 'myplug',                                                       // options / transients / actions
 *       'kill'    => 'MYPLUG_NO_SELF_UPDATE',                                        // wp-config constant that turns it off
 *       'icon'    => '',                                                             // optional icon URL for the Updates list
 *   ) );
 *
 * How it decides (worst case: a bad or tampered release is offered):
 *  - The channel manifest (<base><channel>.json) is fetched at most every 12 h (1 h after a failure). Its package URL must sit
 *    under <base>zips/ or nothing is offered.
 *  - Before WordPress unpacks a download, the zip's SHA-256 must carry a valid Ed25519 signature (<package>.sig) made with the
 *    offline release key, over the message <context><sha256 hex>. Otherwise the update is refused.
 *  - The zip's own "Version:" header must be newer than the running plugin and equal the announced version (no downgrade, no
 *    cross-channel replay).
 *  - Any fetch / JSON / signature failure = no update offered; nothing else changes. WordPress's auto-update toggle stays off by
 *    default. The channel (stable = production, beta = staging) is switched from the plugin's row on the Plugins screen.
 * Changing behaviour? Copy the class to a NEW name (..._2): two plugins may ship different copies and the first one loaded wins
 * the class name, so a name must always mean the same code.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! class_exists( 'Swagat_Release_Updater_1' ) ) {
final class Swagat_Release_Updater_1 {
    private $c;
    private $ver = null;

    public static function register( array $c ) {
        $c = array_merge( array( 'icon' => '', 'kill' => '', 'requires' => '5.2', 'requires_php' => '7.0' ), $c );
        foreach ( array( 'file', 'name', 'base', 'repo', 'pubkey', 'context', 'prefix' ) as $k ) {
            if ( empty( $c[ $k ] ) || ! is_string( $c[ $k ] ) ) { return null; }
        }
        if ( ! preg_match( '/^[a-f0-9]{64}$/', $c['pubkey'] ) || substr( $c['base'], -1 ) !== '/' ) { return null; }
        if ( $c['kill'] !== '' && defined( $c['kill'] ) && constant( $c['kill'] ) ) { return null; }
        $u = new self();
        $u->c = $c;
        $u->hooks();
        return $u;
    }

    private function basename() { return function_exists( 'plugin_basename' ) ? plugin_basename( $this->c['file'] ) : basename( dirname( $this->c['file'] ) ) . '/' . basename( $this->c['file'] ); }
    private function slug() { return dirname( $this->basename() ); }
    private function opt() { return $this->c['prefix'] . '_update_channel'; }
    private function tkey( $ch ) { return $this->c['prefix'] . '_upd_' . $ch; }
    private function zips() { return $this->c['base'] . 'zips/'; }

    /** The running version, read from the plugin header - the header is the one place a version lives. */
    public function version() {
        if ( $this->ver === null ) {
            $d = function_exists( 'get_file_data' ) ? get_file_data( $this->c['file'], array( 'Version' => 'Version' ) ) : array();
            $this->ver = isset( $d['Version'] ) ? (string) $d['Version'] : '0';
        }
        return $this->ver;
    }

    public function channel() {
        $c = function_exists( 'get_option' ) ? (string) get_option( $this->opt(), 'stable' ) : 'stable';
        return $c === 'beta' ? 'beta' : 'stable';
    }

    public function manifest( $force = false ) {
        $ch = $this->channel(); $k = $this->tkey( $ch );
        if ( ! $force && function_exists( 'get_transient' ) ) { $c = get_transient( $k ); if ( is_array( $c ) ) { return $c; } }
        $m = array(); $z = $this->zips();
        if ( function_exists( 'wp_remote_get' ) ) {
            $r = wp_remote_get( $this->c['base'] . $ch . '.json', array( 'timeout' => 10 ) );
            if ( ! is_wp_error( $r ) && (int) wp_remote_retrieve_response_code( $r ) === 200 ) {
                $j = json_decode( (string) wp_remote_retrieve_body( $r ), true );
                if ( is_array( $j ) && isset( $j['version'], $j['package'] ) && is_string( $j['version'] ) && is_string( $j['package'] )
                    && preg_match( '/^\d+(?:\.\d+){1,3}$/', $j['version'] ) && strpos( $j['package'], $z ) === 0
                    && preg_match( '/^[A-Za-z0-9._-]+\.zip$/', substr( $j['package'], strlen( $z ) ) ) ) { $m = $j; }
            }
        }
        if ( function_exists( 'set_transient' ) ) { set_transient( $k, $m, $m ? 43200 : 3600 ); }
        return $m;
    }

    private function icons() {
        $u = (string) $this->c['icon'];
        return $u === '' ? array() : array( 'svg' => $u, '1x' => $u, '2x' => $u, 'default' => $u );
    }

    private function entry( $m ) {
        return array( 'slug' => $this->slug(), 'version' => $m['version'], 'url' => $this->c['repo'], 'package' => $m['package'],
            'requires' => isset( $m['requires'] ) ? (string) $m['requires'] : $this->c['requires'],
            'requires_php' => isset( $m['requires_php'] ) ? (string) $m['requires_php'] : $this->c['requires_php'],
            'tested' => isset( $m['tested'] ) ? (string) $m['tested'] : '', 'icons' => $this->icons() );
    }

    public function verify_zip( $file, $sighex ) {
        try {
            $sighex = strtolower( trim( (string) $sighex ) );
            if ( ! is_file( $file ) || ! preg_match( '/^[a-f0-9]{128}$/', $sighex ) ) { return false; }
            if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) && is_file( ABSPATH . 'wp-includes/sodium_compat/autoload.php' ) ) { require_once ABSPATH . 'wp-includes/sodium_compat/autoload.php'; }
            if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) { return false; }
            $h = hash_file( 'sha256', $file );
            return is_string( $h ) && sodium_crypto_sign_verify_detached( sodium_hex2bin( $sighex ), $this->c['context'] . $h, sodium_hex2bin( $this->c['pubkey'] ) );
        } catch ( \Throwable $e ) { return false; }
    }

    /** '' = fine; otherwise why the package must not be installed. A zip PHP cannot read (no ZipArchive) is allowed. */
    public function zip_version_bad( $file ) {
        if ( ! class_exists( 'ZipArchive' ) ) { return ''; }
        try {
            $z = new ZipArchive();
            if ( $z->open( $file ) !== true ) { return ''; }
            $v = ''; $seen = false; $main = basename( $this->c['file'] );
            for ( $i = 0; $i < $z->numFiles; $i++ ) {
                $n = (string) $z->getNameIndex( $i );
                if ( preg_match( '#^[^/]+/' . preg_quote( $main, '#' ) . '$#', $n ) ) {
                    $seen = true;
                    if ( preg_match( '/^[ \t\/*#@]*Version:[ \t]*([0-9][0-9A-Za-z.\-]*)/mi', (string) $z->getFromName( $n, 8192 ), $mm ) ) { $v = $mm[1]; }
                    break;
                }
            }
            $z->close();
            if ( ! $seen ) { return 'the package does not contain the plugin file'; }
            if ( $v === '' ) { return 'the package has no Version header'; }
            if ( ! version_compare( $v, $this->version(), '>' ) ) { return 'the package is version ' . $v . ', not newer than the installed ' . $this->version(); }
            $m = function_exists( 'get_transient' ) ? get_transient( $this->tkey( $this->channel() ) ) : false;
            if ( is_array( $m ) && ! empty( $m['version'] ) && is_string( $m['version'] ) && $m['version'] !== $v ) { return 'the package is version ' . $v . ' but ' . $m['version'] . ' was announced'; }
            return '';
        } catch ( \Throwable $e ) { return ''; }
    }

    public function pre_download( $reply, $package ) {
        if ( $reply !== false || ! is_string( $package ) || strpos( $package, $this->zips() ) !== 0 ) { return $reply; }
        if ( ! function_exists( 'download_url' ) ) { require_once ABSPATH . 'wp-admin/includes/file.php'; }
        $tmp = download_url( $package, 300 );
        if ( is_wp_error( $tmp ) ) { return $tmp; }
        $sr = wp_remote_get( $package . '.sig', array( 'timeout' => 10 ) );
        $sig = ( ! is_wp_error( $sr ) && (int) wp_remote_retrieve_response_code( $sr ) === 200 ) ? (string) wp_remote_retrieve_body( $sr ) : '';
        if ( $this->verify_zip( $tmp, $sig ) ) {
            $why = $this->zip_version_bad( $tmp );
            if ( $why === '' ) { return $tmp; }
            @unlink( $tmp );
            return new WP_Error( $this->c['prefix'] . '_bad_version', $this->c['name'] . ': the update was refused because ' . $why . '.' );
        }
        @unlink( $tmp );
        return new WP_Error( $this->c['prefix'] . '_bad_signature', $this->c['name'] . ': the update package signature did not verify, so the update was refused.' );
    }

    private function hooks() {
        $self = $this;
        $host = (string) parse_url( $this->c['repo'], PHP_URL_HOST );
        // WordPress 5.8+: asked about every plugin whose "Update URI" has this host; answer only for our own file.
        add_filter( 'update_plugins_' . $host, function ( $update, $plugin_data = array(), $plugin_file = '' ) use ( $self ) {
            if ( (string) $plugin_file !== $self->basename_public() ) { return $update; }
            $m = $self->manifest( isset( $_GET['force-check'] ) );
            return $m ? $self->entry_public( $m ) : $update;
        }, 10, 3 );
        add_filter( 'upgrader_pre_download', function ( $reply, $package = '' ) use ( $self ) { return $self->pre_download( $reply, $package ); }, 10, 2 );
        add_filter( 'plugins_api', function ( $res, $action = '', $args = null ) use ( $self ) {
            if ( $action !== 'plugin_information' || ! is_object( $args ) || ! isset( $args->slug ) || $args->slug !== $self->slug_public() ) { return $res; }
            $m = $self->manifest();
            if ( ! $m ) { return $res; }
            $e = $self->entry_public( $m );
            return (object) array( 'name' => $self->cfg( 'name' ), 'slug' => $e['slug'], 'version' => $e['version'], 'homepage' => $self->cfg( 'repo' ),
                'requires' => $e['requires'], 'requires_php' => $e['requires_php'], 'download_link' => $e['package'],
                'sections' => array( 'changelog' => function_exists( 'wp_kses_post' ) ? wp_kses_post( isset( $m['changelog'] ) ? (string) $m['changelog'] : '' ) : '' ) );
        }, 10, 3 );
        // "Check again" on Dashboard -> Updates forces only the core check; clear this plugin's manifest cache too.
        add_action( 'load-update-core.php', function () use ( $self ) {
            if ( empty( $_GET['force-check'] ) || ! current_user_can( 'update_plugins' ) ) { return; }
            $self->flush();
        }, 1 );
        // Every save of the plugin-update record carries our entry from the CACHED manifest (no network call here), when newer.
        // Covers WordPress before 5.8 (no Update URI filter) and a slow wordpress.org answer. The package is still verified on download.
        add_filter( 'pre_set_site_transient_update_plugins', function ( $value ) use ( $self ) {
            try {
                if ( ! is_object( $value ) ) { return $value; }
                $pf = $self->basename_public();
                if ( isset( $value->response ) && is_array( $value->response ) && isset( $value->response[ $pf ] ) ) { return $value; }
                $m = get_transient( $self->tkey_public( $self->channel() ) );
                if ( ! is_array( $m ) || empty( $m['version'] ) || empty( $m['package'] ) || ! is_string( $m['version'] ) || ! is_string( $m['package'] )
                     || strpos( $m['package'], $self->zips_public() ) !== 0 || ! version_compare( $m['version'], $self->version(), '>' ) ) { return $value; }
                if ( ! isset( $value->response ) || ! is_array( $value->response ) ) { $value->response = array(); }
                $e = $self->entry_public( $m );
                $value->response[ $pf ] = (object) array_merge( $e, array( 'id' => $self->cfg( 'repo' ), 'plugin' => $pf, 'new_version' => $e['version'], 'banners' => array(), 'banners_rtl' => array() ) );
                if ( isset( $value->no_update ) && is_array( $value->no_update ) ) { unset( $value->no_update[ $pf ] ); }
            } catch ( \Throwable $e ) {}
            return $value;
        } );
        // The channel switch: one line under the plugin on the Plugins screen.
        add_filter( 'plugin_row_meta', function ( $meta, $file ) use ( $self ) {
            if ( $file !== $self->basename_public() || ! current_user_can( 'update_plugins' ) ) { return $meta; }
            $ch = $self->channel(); $to = $ch === 'beta' ? 'stable' : 'beta';
            $url = wp_nonce_url( admin_url( 'admin-post.php?action=' . $self->cfg( 'prefix' ) . '_upd_channel&to=' . $to ), $self->cfg( 'prefix' ) . '_upd_channel' );
            $meta[] = 'Update channel: <strong>' . esc_html( ucfirst( $ch ) ) . '</strong> (<a href="' . esc_url( $url ) . '">switch to ' . esc_html( $to ) . '</a>)';
            return $meta;
        }, 10, 2 );
        add_action( 'admin_post_' . $this->c['prefix'] . '_upd_channel', function () use ( $self ) {
            if ( ! current_user_can( 'update_plugins' ) ) { wp_die( 'Not allowed' ); }
            check_admin_referer( $self->cfg( 'prefix' ) . '_upd_channel' );
            $to = ( isset( $_GET['to'] ) && $_GET['to'] === 'beta' ) ? 'beta' : 'stable';
            update_option( $self->cfg( 'prefix' ) . '_update_channel', $to, false );
            $self->flush();
            wp_safe_redirect( admin_url( 'plugins.php' ) );
            exit;
        } );
    }

    public function flush() {
        delete_transient( $this->tkey( 'stable' ) ); delete_transient( $this->tkey( 'beta' ) ); delete_site_transient( 'update_plugins' );
    }

    /* closures cannot call private methods of $self on PHP 7.0 - thin public wrappers */
    public function cfg( $k ) { return isset( $this->c[ $k ] ) ? $this->c[ $k ] : ''; }
    public function basename_public() { return $this->basename(); }
    public function slug_public() { return $this->slug(); }
    public function tkey_public( $ch ) { return $this->tkey( $ch ); }
    public function zips_public() { return $this->zips(); }
    public function entry_public( $m ) { return $this->entry( $m ); }
}
}
